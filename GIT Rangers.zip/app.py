import os
from flask import Flask, request, jsonify, render_template
import llm

app = Flask(__name__, template_folder='templates', static_folder='static')

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
document_store = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/upload', methods=['POST'])
def upload_and_process_document():


    file = request.files['file']
    target_language = request.form.get('language', 'Hindi')

    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if file:
        filename = file.filename
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        document_text = llm.extract_text_from_file(file_path)
        document_store[filename] = {"text": document_text, "history": ""}

        task = llm.determine_document_task(document_text)
        summary = llm.get_llm_response_for_task(task, document_text)

        translated_summary = llm.translate_text(summary, target_language)
        return jsonify({
            "summary": summary,
            "translated_summary": translated_summary,
            "language": target_language,
            "doc_id": filename # Pass a document identifier back to the client
        })
     
@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.get_json()
    user_question = data.get('question')
    doc_id = data.get('doc_id')
    doc_session = document_store.get(doc_id)
 
    document_text = doc_session["text"]
    chat_history = doc_session["history"]

    answer = llm.chat_with_document(document_text, user_question, chat_history)
    doc_session["history"] += f"User: {user_question}\nAssistant: {answer}\n"

    return jsonify({"answer": answer})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)