document.addEventListener('DOMContentLoaded', () => {
    const uploadForm = document.getElementById('upload-form');
    const chatForm = document.getElementById('chat-form');
    const fileInput = document.getElementById('file-input');
    const chatInput = document.getElementById('chat-input');
    const chatWindow = document.getElementById('chat-window');
    const loader = document.getElementById('loader');
    const chatLoader = document.getElementById('chat-loader');
    const uploadError = document.getElementById('upload-error');
    const uploadButton = document.getElementById('upload-button');

    const resultsSection = document.getElementById('results-section');
    const chatSection = document.getElementById('chat-section');
    const summaryOutput = document.getElementById('summary-output');
    const translatedSummaryOutput = document.getElementById('translated-summary-output');
    const translatedSummaryTitle = document.getElementById('translated-summary-title');

    let docId = null; // To store the document identifier for the chat session

    // --- Handle Document Upload ---
    uploadForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        if (!fileInput.files.length) {
            uploadError.textContent = 'Oops! It looks like you haven\'t selected a file yet.';
            return;
        }

        const formData = new FormData(uploadForm);
        
        // Show loader and disable button
        loader.style.display = 'block';
        uploadError.textContent = '';
        uploadButton.disabled = true;
        uploadButton.textContent = 'Analyzing...';

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData,
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Something went wrong on our end. Please try again.');
            }

            // Populate results
            summaryOutput.textContent = result.summary;
            translatedSummaryOutput.textContent = result.translated_summary;
            translatedSummaryTitle.textContent = `Translated Summary (${result.language})`;
            docId = result.doc_id;

            // Show results and chat sections
            resultsSection.style.display = 'block';
            chatSection.style.display = 'flex';

        } catch (error) {
            uploadError.textContent = `Error: ${error.message}`;
        } finally {
            // Hide loader and re-enable button
            loader.style.display = 'none';
            uploadButton.disabled = false;
            uploadButton.textContent = 'Analyze Document';
        }
    });

    // --- Handle Chat Interaction ---
    chatForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const userQuestion = chatInput.value.trim();

        if (!userQuestion || !docId) {
            return;
        }

        // Display user's message
        addChatMessage(userQuestion, 'user');
        chatInput.value = '';
        
        // Show chat loader and disable input
        chatLoader.style.display = 'block';
        chatInput.disabled = true;

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    question: userQuestion,
                    doc_id: docId,
                }),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Failed to get a response. Maybe the server is busy?');
            }

            // Display bot's response
            addChatMessage(result.answer, 'bot');

        } catch (error) {
            addChatMessage(`My apologies, something went wrong. Could you please try asking your question again?`, 'bot');
        } finally {
            chatLoader.style.display = 'none';
            chatInput.disabled = false;
        }
    });

    /**
     * Adds a message to the chat window.
     * @param {string} message The message text.
     * @param {'user' | 'bot'} sender The sender of the message.
     */
    function addChatMessage(message, sender) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('chat-message', sender);

        const paragraph = document.createElement('p');
        paragraph.textContent = message;

        messageElement.appendChild(paragraph);
        chatWindow.appendChild(messageElement);

        // Scroll to the bottom
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }
});